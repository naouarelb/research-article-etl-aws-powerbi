import boto3
import zipfile
import io
import csv
import json

s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        bucket_name = event['bucket_name']
        file_key = event['file_key']
        destination_folder = event['destination_folder']

        print(f"Processing file: {file_key}")

        # Check if the file is a .zip file
        if file_key.endswith('.zip'):
            # Download the zip file
            zip_file = s3.get_object(Bucket=bucket_name, Key=file_key)['Body'].read()

            # Open the zip file
            with zipfile.ZipFile(io.BytesIO(zip_file), 'r') as zip_ref:
                # Extract all files in the zip archive
                for file_info in zip_ref.infolist():
                    # Check if the file is a CSV file
                    if file_info.filename.endswith('.csv'):
                        print(f'Reading CSV file: {file_info.filename}')

                        # Read the CSV file from the zip archive
                        with zip_ref.open(file_info) as file:
                            # Use io.TextIOWrapper to decode the file
                            csv_file = io.TextIOWrapper(file, encoding='utf-8')

                            # Read the CSV file line by line
                            reader = csv.reader(csv_file)
                            header = next(reader)  # Read the header

                            # Prepare the output with the new delimiter (|)
                            output = io.StringIO()
                            writer = csv.writer(output, delimiter='|', quotechar=None, quoting=csv.QUOTE_NONE, escapechar='\\')

                            # Rename the column "Art. No." to "Art_no" in the header
                            if "Art. No." in header:
                                header[header.index("Art. No.")] = "Art_no"

                            # Write the updated header
                            writer.writerow(header)

                            # Process each row
                            for row in reader:
                                writer.writerow(row)

                            # Define the output file key
                            output_file_key = f"{destination_folder}{file_info.filename}"

                            # Upload the updated CSV file to S3
                            s3.put_object(Bucket=bucket_name, Key=output_file_key, Body=output.getvalue())
                            print(f'Processed file saved to: {output_file_key}')
        else:
            print(f'Skipping non-zip file: {file_key}')

        return {
            'statusCode': 200,
            'body': json.dumps('File processed successfully!')
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Failed to process file.',
                'error': str(e)
            })
        }